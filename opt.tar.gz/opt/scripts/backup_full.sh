#!/bin/bash
# Script de backup con argumentos: origen y destino
# Guardado en /opt/scripts/backup_full.sh

# Opción de ayuda
if [ "$1" == "-help" ]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo ""
    echo "Este script genera un archivo comprimido (.tar.gz) del directorio <origen>"
    echo "y lo guarda en el directorio <destino> con nombre:"
    echo "    <nombre_origen>_bkp_YYYYMMDD.tar.gz"
    exit 0
fi

# Validar argumentos
if [ $# -ne 2 ]; then
    echo "Error: número de argumentos inválido."
    echo "Use '$0 -help' para ver la ayuda."
    exit 1
fi

ORIGEN=$1
DESTINO=$2

# Validar que el origen exista y sea accesible
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi

# Validar que el destino exista y esté montado
if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino '$DESTINO' no está montado como partición válida."
    exit 1
fi

# Fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Crear directorio destino si no existe
mkdir -p "$DESTINO"

# Nombre del archivo de backup
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

echo "🔄 Respaldando $ORIGEN → $ARCHIVO"
tar czf "$ARCHIVO" "$ORIGEN"

echo "✅ Backup finalizado en $ARCHIVO"