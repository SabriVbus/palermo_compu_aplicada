#!/bin/bash
# Script de backup con argumentos: origen y destino
# Guardado en /opt/scripts/backup_full.sh

# Ayuda
if [ "$1" == "-help" ]; then
    echo "Uso: $0 <origen1> [origen2 ...] <destino>"
    echo
    echo "Ejemplos:"
    echo "  $0 /var/log /backup_dir"
    echo "    → Genera log_bkp_YYYYMMDD.tar.gz en /backup_dir"
    echo
    echo "  $0 /etc /var/log /home /backup_dir"
    echo "    → Genera etc_bkp_YYYYMMDD.tar.gz, log_bkp_YYYYMMDD.tar.gz y home_bkp_YYYYMMDD.tar.gz en /backup_dir"
    exit 0
fi

# Validar argumentos
if [ $# -lt 2 ]; then
    echo "Error: número de argumentos inválido."
    echo "Use '$0 -help' para ver la ayuda."
    exit 1
fi

# El último argumento es el destino
DESTINO=${!#}

# Fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Recorremos todos los argumentos menos el último (que es destino)
for ((i=1; i<$#; i++)); do
    ORIGEN=${!i}

# Validar que el destino exista y esté montado
if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino '$DESTINO' no está montado como partición válida."
    exit 1
fi

# Validar que el origen exista
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio de origen '$ORIGEN' no existe o no está disponible."
    continue
fi

    NOMBRE=$(basename "$ORIGEN")
    ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

    echo "Respaldando $ORIGEN → $ARCHIVO"
    tar czf "$ARCHIVO" "$ORIGEN"
done

echo "Backups finalizados en $DESTINO"