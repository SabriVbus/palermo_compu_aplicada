history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
apt upgrade
apt full-upgrade -y
reboot
lsb_release -a
vi /etc/apt/sources.list
apt clean
apt update
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt clear
apt update
apt full-upgrade -y
reboot
lsblk
sudo mount /dev/sr0 /mnt
ls /mnt
sudo /mnt/VBoxLinuxAdditions.run
sudo reboot
