history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
vi /etc/hostname
vi /etc/hosts
reboot
apt update
vi /etc/apt/sourcers.list
vi /etc/apt/sources.list
apt update
li /etc/apt/
ls /etc/apt/
apt full-upgrade
apt upgrade
apt full-upgrade
apt --purge autoremove
reboot
vi /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs
apt full-upgrade
lsb release -a
lsb_release -a
vi /etc/apt/sources.list
apt update
apt install openssh-server -y
reboot
mkdir -p /roo/.ssh
chmod 700 /root/.ssh
ls /media
apt install virtualbox-guest.utils -y
apt install virtualbox-guest-utils -y
apt install virtualbox-guest-additions-iso
mkdi /mnt/logo
clear
mkdir /mnt/logo
mount -t vboxsf Logo /mnt/logo
cp /mnt/logo/id_rsa.pub /root/.ssh/authorized_keys
chmo 600 /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
chmod 700 /root/.ssh
cat /root/.ssh/authorized_keys
ip addr show
hostname -I
vi /etc/ssh/sshd_config
clear
systemctl restar ssh
systemctl restart ssh
cat /root/.ssh/authorized_keys
reboot
php -v
apt update
apt intall apache2 php libapache2-mod.php -y
apt install apache2 php libapache2-mod.php -y
apt install apache2 php libapache2-mod-php -y
php -v
cp /mnt/logo/index.php /root/
ls /mnt/logo
mount -t vboxsf Logo /media/shared
apt list --intalled | grep virtualbox-guest-additions-iso
apt list --installed | grep virtualbox-guest-additions-iso
ls -l /mnt/logo
apt install sudo
apt update
sudo mount -t vboxsf Logo /mnt/logo
cp /mnt/logo/index.php /root/
cp /mnt/logo/logo.png /root/
sudo vi /etc/apache2/sites-available/roothome.conf
clear
sudo a2dissite 00-default.conf
sudo a2dissite 000-default.conf
systemctl reload apache2
sudo a2dissite 000-default.conf
sudo a2dissite roothome.conf
sudo systemctl reload apache2
sudo a2ensite roothome.conf
sudo systemctl reload apache2
sudo systemctl status apache2.service
sudo vi /etc/apache2/sites-available/roothome.conf
clear
sudo apache2ctl configtest
sudo systemctl reload apache2
hostmane -I
hostname -I
sudo systemctl status apache2.service
sudo chmod 755 /root
sudo chmod 644 /root/index.php /root/logo.png
sudo systemctl reload apache2
sudo tail -f /var/log/apache2/error.log
sudo vi /root/index.php
sudo systemctl reload apache2
sudo apt install mariadb-server -y
ls -l /root
sudo systemctl status mariadb
sudo mysql_secure_installation
sudo mysql
cp /mnt/logo/db.sql /root/
sudo mysql
sudo mysql ingenieria < /root/db.sql
sudo mysql
sudo mysql ingenieria < /root/db.sql
sudo mysql ingenieria
sudo mysql ingenieria < /root/db.sql
sudo mysql -u root -p < /root/db.sql
sudo mysql
sudo mysql -u root -p
sudo mysql -u root -p < /root/db.sql
sudo mysql -u root -p
sudo mysql < /root/db.sql
sudo mysql -u root -p -e "DROP DATABASE ingenieria;"
sudo mysql < /root/db.sql
sudo mysql -u root -p -e "DROP USER 'lcars'@'%'"
sudo mysql < /root/db.sql
sudo mysql -u root -p -e "DROP DATABASE ingenieria;"
sudo mysql < /root/db.sql
sudo mysql
sudo mysql -u root ingenieria -e "SHOW TABLES;"
clear
reboot
